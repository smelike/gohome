package services

type UserService struct {
}

func (that *UserService) Get(params *map[string]interface{}, result *map[string]interface{}) error {
	return nil
}
